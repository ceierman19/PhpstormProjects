<?php
    header("Content-Type: application/json");  // formats JSON
    $method = strtolower($_SERVER["REQUEST_METHOD"]);

    $data = json_decode(file_get_contents("php://input"));

    $response = array();

    if ($method == "get") {
        $response["dateAccessed"] = date("F j, Y, g:i a");
        $response["temp"] = "72 °F";
        $response["humidity"] = "20 %";
        $response["moisture"] = 1000;
    }
    else if ($method == "post") {
        $response["dateCreated"] = time();
        $response["originServer"] = gethostname();
        $response["favSensor"] = $data->favSensor;
    }
    else {
        http_response_code(405);
    }

    echo json_encode($response);
?>