<?php
    function createGreeting($name) {
        return "Hello $name";
    }

    $name = "CSC 330";
    echo createGreeting($name) . "<br />";

    $regArray = array("A", "B", "C");
    echo $regArray[1] . "<br />";

    $keyedArray = array("Name" => "Brian", "Age" => 45);
    echo $keyedArray["Age"] . "<br />";
    print_r($keyedArray);
    die(); // code below will not execute

    foreach($regArray as $letter) {
        echo $letter . "<br />";
    }

    foreach($keyedArray as $key=>$val) {
        echo $key . " = " . $val . "<br />";
    }

    $password = "secure";
    if ($password == "secure") {
        echo "You are logged in";
    }
    else {
        echo "Failed to log in";
    }
?>
