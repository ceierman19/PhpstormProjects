<?php
    require_once(__DIR__ . "/Database.php");

    header("Content-Type: application/json");  // formats JSON
    $method = strtolower($_SERVER["REQUEST_METHOD"]);

    $data = json_decode(file_get_contents("php://input"));

    $response = array();

    if ($method == "get") {
        $response = Database::getOrders();
    }
    else if ($method == "post") {
        $id = Database::createOrder($data->emailAddress, $data->itemName, $data->itemPrice);
        $response["id"] = $id;
    }
    else if ($method == "put") {
        $rows = Database::updateOrder($data->emailAddress, $data->itemName, $data->itemPrice, $data->orderId);
        $response["numAffectedRows"] = $rows;
    }
    else if ($method == "delete") {
        $rows = Database::deleteOrder($data->orderId);
        $response["numAffectedRows"] = $rows;
    }
    else {
        http_response_code(405);
    }

    echo json_encode($response);
?>