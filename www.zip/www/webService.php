<?php
    $response["message"] = "hello";
    $response["date"] = date("F j, Y, g:i a");
    echo json_encode($response);

    // {"message":"hello","date":"March"}
?>