<?php

class Database {
    static public function getOrders() {
        $db = self::getDbConnection();
        $statement = $db->prepare("SELECT orderId, emailAddress, itemName, itemPrice from tblOrders");
        $results = array();

        if ($statement->execute() === FALSE) {
            return false;
        }

        $statement->bind_result($orderId, $emailAddress, $itemName, $itemPrice);
        while($statement->fetch()) {
            $result["orderId"] = $orderId;
            $result["emailAddress"] = $emailAddress;
            $result["itemName"] = $itemName;
            $result["itemPrice"] = $itemPrice;

            array_push($results, $result);
        }

        return $results;
    }

    static public function createOrder($emailAddress, $itemName, $itemPrice) {
        $db = self::getDbConnection();

        /**
         * Bind Parameters
         * s- string
         * d- double or float
         * i - integer
         * b- blob
         */

        $statement = $db->prepare("INSERT INTO tblOrders (emailAddress, itemName, itemPrice) VALUES (?,?,?)");
        $statement->bind_param("ssd", $emailAddress, $itemName, $itemPrice);

        if ($statement->execute() === FALSE) {
            return false;
        }
        return $statement->insert_id;
    }

    static public function updateOrder($emailAddress, $itemName, $itemPrice, $orderId) {
        $db = self::getDbConnection();

        $statement = $db->prepare("UPDATE tblOrders SET emailAddress = ?, itemName = ?, itemPrice = ? WHERE orderId = ?");
        $statement->bind_param("ssdi", $emailAddress, $itemName, $itemPrice, $orderId);

        if ($statement->execute() === FALSE) {
            return false;
        }
        return $statement->affected_rows;
    }

    static public function deleteOrder($orderId) {
        $db = self::getDbConnection();

        $statement = $db->prepare("DELETE FROM tblOrders WHERE orderId = ?");
        $statement->bind_param("i", $orderId);

        if ($statement->execute() === FALSE) {
            return false;
        }
        return $statement->affected_rows;
    }

    static private function getDbConnection() {
        $servername = "localhost";
        $username = "csc330_shared";
        $password = "neverincode";
        $database = $username;

        $db = new mysqli($servername, $username, $password, $database);

        if ($db->connect_errno) {
            return false;
        }
        return $db;
    }
}