<?php
$ledButtonAction = "Turn Light On";
$ledButton = "on";
$servoButtonAction = "Lock";
$servoButton = "locked";

if ($_POST["buttonAction"] == "ledButton" && $_POST["ledToggle"] == "on") {
    $ledButton = "off";
    $ledButtonAction = "Turn Light Off";

    $command = escapeshellcmd("/usr/bin/python3 -u /home/pi/Desktop/iot_programs/lightOn.py");
    $output = shell_exec($command);
}

if ($_POST["buttonAction"] == "ledButton" && $_POST["ledToggle"] == "off") {
    $command = escapeshellcmd("/usr/bin/python3 -u /home/pi/Desktop/iot_programs/lightOff.py");
    shell_exec($command);
}

if ($_POST["buttonAction"] == "servoButton" && $_POST["servoToggle"] == "locked") {
    $servoButton = "unlocked";
    $servoButtonAction = "Unlock";

    $command = escapeshellcmd("/usr/bin/python3 -u /home/pi/Desktop/iot_programs/servoLock.py");
    shell_exec($command);
}

if ($_POST["buttonAction"] == "servoButton" && $_POST["servoToggle"] == "unlocked") {
    $command = escapeshellcmd("/usr/bin/python3 -u /home/pi/Desktop/iot_programs/servoUnlock.py");
    shell_exec($command);
}
?>

<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>IoT Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

    <style>
        body {
            background-color: rgb(0,255,255);
        }
    </style>
</head>

<body>
<div class="container" id="mainContent">
    <div class="row">
        <div class="col-12 text-center">
            <h1>IoT Dashboard</h1>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
                    integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN"
                    crossorigin="anonymous"></script>
        </div>
    </div>

    <div class="row">
        <div class="row">
            <div class="col-md-4 col-sm-12 text-center">
                <form action="index.php" method="post">
                    <input type="hidden" name="buttonAction" value="ledButton" />
                    <input type="hidden" name="ledToggle" value="<?=$ledButton?>" />
                    <input type="submit" class="btn btn-primary" value="<?=$ledButtonAction?>" />
                </form>
            </div>

            <div class="col-md-4 col-sm-12 text-center">
                <p>
                    <?php
                    $output = null;
                    $command = escapeshellcmd("/usr/bin/python3 -u /home/pi/Desktop/iot_programs/sensor.py");
                    $output = shell_exec($command);
                    echo $output;
                    ?>
                </p>
            </div>

            <div class="col-md-4 col-sm-12 text-center">
                <form action="index.php" method="post">
                    <input type="hidden" name="buttonAction" value="servoButton" />
                    <input type="hidden" name="servoToggle" value="<?=$servoButton?>" />
                    <input type="submit" class="btn btn-primary" value="<?=$servoButtonAction?>" />
                </form>
            </div>
        </div>
        <br />
    </div>
</div>

</body>

</html>
